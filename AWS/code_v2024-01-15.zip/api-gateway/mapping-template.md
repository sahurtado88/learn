#set($inputRoot = $input.path('$'))
{ 
   "renamedexample" : $inputRoot.example,
   "anotherkey" : "anothervalue"
}


